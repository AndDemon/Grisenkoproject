package org.example;

public interface ExtCalcFactory extends CalcFactory {
    TableDisplay createTableDisplay();
}