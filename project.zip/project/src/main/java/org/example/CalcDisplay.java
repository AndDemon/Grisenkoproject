package org.example;

public interface CalcDisplay {
    //відображення параметрів обчислень
    void displayParameters(Calc data);
    //відображення результатів обчислень
    void displayResult(Calc data);
}