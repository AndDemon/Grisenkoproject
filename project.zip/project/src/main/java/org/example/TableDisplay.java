package org.example;

public interface TableDisplay {
    void displayTable(Calc data, String[] headers);
}